<footer>
  <div class="container-fluid bg-dark py-3">
    <div class="col-12 text-center">
      <p class="text-white">
        ©2023 Delivery Chef. All rights reserved
      </p>
    </div>
  </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="scripts/script.js"></script>
</body>

</html>