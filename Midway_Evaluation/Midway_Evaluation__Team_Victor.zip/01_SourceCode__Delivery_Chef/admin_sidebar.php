<div class="sidebar p-4 text-center" id="side_nav">
  <div class="side-header px-2 pt-3 pb-4">
    <h1 class="fs-4"><a href="index.php">Delivery<span>Chef</span></a></h1>
  </div>

  <ul class="side-menu list-unstyled px-2">
    <li class="">
      <a href="dashboard.php" class="text-decoration-none py-2 d-block"><i
          class="bi bi-speedometer"></i></i>Dashboard</a>


    <li>
      <a href="admin_menu_dashbd.php" class="text-decoration-none py-2 d-block"><i class="bi bi-book"></i>Menu</a>
    </li>

    <li>
      <a href="admin_orders.php" class="text-decoration-none py-2 d-block"><i class="bi bi-cart"></i>Orders</a>
    </li>

    <li>
      <a href="admin_orders.php" class="text-decoration-none py-2 d-block">
    </li><i class="bi bi-truck"></i>Delivery</a>
    </li>

    <li>
      <a href="admin_users.php" class="text-decoration-none py-2 d-block"><i class="bi bi-person"></i>Users</a>
    </li>

    <li>
      <a href="admin_employees.php" class="text-decoration-none py-2 d-block"><i class="bi bi-person"></i>Employees</a>
    </li>

    <li>
      <a href="index.php" class="text-decoration-none py-2 d-block logout mb-5"><i
          class="bi bi-box-arrow-right"></i>Logout</a>
    </li>
  </ul>

</div>