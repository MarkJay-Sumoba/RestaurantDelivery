-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3304
-- Generation Time: Oct 30, 2023 at 05:33 PM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsd10_victor`
--
CREATE DATABASE IF NOT EXISTS `fsd10_victor` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `fsd10_victor`;

-- --------------------------------------------------------

--
-- Table structure for table `food_cat`
--

CREATE TABLE `food_cat` (
  `foodcat_id` int(11) NOT NULL,
  `foodcat_desc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `food_cat`
--

INSERT INTO `food_cat` (`foodcat_id`, `foodcat_desc`) VALUES
(100, 'Entree'),
(200, 'Vegetarian'),
(300, 'Meat'),
(400, 'Seafood'),
(500, 'Beverage');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL,
  `dish_title` varchar(100) NOT NULL,
  `foodcat_id` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `dish_title`, `foodcat_id`, `price`, `image`, `description`) VALUES
(4, 'Chinese Vegetable Soup with Tofu', 100, 9, 'image/menu/100_Chinese_Vegetable_Soup_with_Tofu.jpg', 'Experience the perfect harmony of flavors in our Chinese Vegetable Soup with Tofu. This delectable soup is a vegetarian delight, combining fresh, crisp vegetables with silky tofu in a savory broth. Each spoonful is a journey through the heart of Chinese cuisine, offering a comforting warmth that soothes the soul. Whether you\'re a vegetarian or simply craving a wholesome and satisfying soup, this dish is a must-try. Join us and savor the essence of traditional Chinese cooking with our delightful Vegetable Soup with Tofu'),
(5, 'Wonton Soup', 100, 8, 'image/menu/100_Wonton_Soup.jpg', 'Indulge in the ultimate comfort food experience with our Wonton Soup with Tofu. This classic soup combines succulent, handcrafted wontons filled with flavorful goodness, gently floating in a savory, aromatic broth. The addition of delicate tofu cubes elevates this dish to a new level of satisfaction. Every spoonful is a harmonious blend of textures and tastes, making it a delightful choice for both meat lovers and vegetarians. Join us for a bowl of pure culinary comfort, and discover the joy of Wonton Soup with Tofu at its finest.'),
(6, 'Crispy Teriyaki Tofu and Broccoli', 200, 15, 'image/menu/200_Sheet_Pan_Crispy_Teriyaki_Tofu_Broccoli.jpg', 'Discover the perfect balance of textures and flavors with our Crispy Teriyaki Tofu and Broccoli. Tender tofu, lightly fried to a crispy perfection, is paired with vibrant broccoli florets, all generously coated in our signature teriyaki sauce. This delectable dish offers a delightful contrast between the crunchy tofu and the tender broccoli, while the sweet and savory teriyaki glaze ties it all together. Whether you\'re a tofu enthusiast or looking for a satisfying and wholesome meal, our Crispy Teriyaki Tofu and Broccoli is a delightful choice. Come experience the fusion of crispiness and succulence in every bite.\n'),
(7, 'Stir Fried Vegetables', 200, 16, 'image/menu/200_Stir_Fry_Vegetables.jpg', 'Elevate your dining experience with our enticing Stir-Fried Vegetables. A vibrant medley of fresh, seasonal vegetables is expertly sautéed to perfection, capturing the essence of simplicity and flavor. The natural colors and crunchiness of the vegetables are enhanced by our secret stir-fry sauce, creating a dish that is both wholesome and irresistible. Whether you\'re a devoted vegetarian or simply in search of a healthy and flavorful option, our Stir-Fried Vegetables are the epitome of culinary excellence. Join us for a taste of pure delight and savor the goodness of nature\'s bounty in every bite.'),
(14, 'Chinese Pepper Steak', 300, 16, 'image/menu/300_Chinese_Pepper_Steak.jpg', 'Indulge in the exquisite flavors of our Chinese Pepper Steak, a culinary masterpiece that invites your taste buds on a journey through the heart of Chinese cuisine. This delectable dish showcases succulent cuts of beef, stir-fried to perfection with a medley of crisp, vibrant vegetables, all harmoniously blended with a rich and aromatic symphony of Chinese spices and sauces.\n\nOur secret ingredient, Chinese pepper, adds a tantalizing hint of fragrance and just the right amount of subtle spiciness, creating a mouthwatering sensation that will leave you craving for more. Whether it\'s a special celebration or a cozy family dinner, our Chinese Pepper Steak is the ideal choice to elevate your dining experience.\n\nWhat sets us apart is the ability to customize this dish to suit your unique preferences. We\'re dedicated to ensuring that every plate served is a personalized masterpiece that caters to your specific tastes. So why not explore the captivating world of Chinese cuisine and savor the flavors of our Chinese Pepper Steak? Your culinary adventure awaits!'),
(15, 'Mongolian Beef', 300, 17, 'image/menu/300_Mongolian_Beef.jpg', 'Experience the bold and savory allure of our Mongolian Beef, a dish that brings the rich flavors of Mongolia to your plate. Succulent strips of tender beef are wok-fried to perfection, then generously coated with a delectable, sweet and savory sauce. Our chefs skillfully infuse this classic Mongolian recipe with their own unique touch.\n\nEach bite is a harmonious blend of succulent beef, crisp scallions, and a symphony of flavors that captures the essence of this beloved Asian dish. It\'s a tantalizing journey for your taste buds, providing a perfect balance of textures and tastes.\n\nMongolian Beef is a true crowd-pleaser, suitable for any occasion. Whether you\'re joining us for a quick lunch or a special dinner, this dish promises an unforgettable culinary experience. We invite you to savor the taste of Mongolia right here in our restaurant, where tradition meets innovation for a truly memorable dining adventure.'),
(16, 'Butter Poached Lobster', 400, 25, 'image/menu/400_Butter_Poached_Lobster.jpg', 'Indulge in the epitome of luxury with our Butter Poached Lobster, a masterpiece that epitomizes seafood perfection. Succulent lobster tail, bathed in velvety butter, is expertly poached to tender, mouthwatering perfection. This exquisite dish exudes an unparalleled richness and depth of flavor.\r\n\r\nThe buttery poaching process imparts a luscious, melt-in-your-mouth texture to each morsel of lobster, while preserving its natural sweetness. This culinary experience is a true celebration of the sea\'s finest delicacies, elevated to an art form.\r\n\r\nButter Poached Lobster is the epitome of elegance and sophistication, making it the ideal choice for special occasions and romantic dinners. It\'s an opportunity to savor the sublime taste of the ocean, brought to you with a touch of culinary finesse. Join us and savor this exquisite masterpiece, where every bite is an ode to seafood opulence.'),
(17, 'Shrimp Fried Rice', 400, 16, 'image/menu/400_Shrimp_Fried_Rice.jpg', 'Delight in the classic flavors of our Shrimp Fried Rice, a timeless favorite that\'s the perfect blend of simplicity and deliciousness. Plump, succulent shrimp are expertly stir-fried with fluffy rice, farm-fresh vegetables, and our secret blend of savory seasonings.\r\n\r\nEach forkful of Shrimp Fried Rice offers a tantalizing combination of textures and tastes, from the tender shrimp to the perfectly cooked vegetables, all kissed with the savory aroma of our signature seasonings. This dish is a comforting and satisfying choice that never goes out of style.\r\n\r\nShrimp Fried Rice is the ideal companion for a quick lunch or a laid-back dinner, offering both heartwarming comfort and a taste of culinary excellence. Join us and savor this timeless classic, where every bite transports you to a world of flavor.'),
(18, 'Shrimp and Rice with Soybean sauce', 400, 16, 'image/menu/400_Shrimp_Rice_SoyBean_sauce.jpg', 'Embark on a culinary adventure with our Shrimp and Rice with Soybean Sauce, a dish that combines the exquisite flavors of the sea and the depth of umami. Plump, succulent shrimp are meticulously cooked and then lovingly drizzled with our secret soybean sauce, which infuses every bite with a burst of rich, savory goodness.\r\n\r\nThis dish brings together the succulence of shrimp and the comforting embrace of rice, creating a harmonious balance of textures and tastes. The soybean sauce, a culinary treasure, adds depth and complexity to each mouthful, making it a true gourmet experience.\r\n\r\nShrimp and Rice with Soybean Sauce is the epitome of fusion cuisine, where tradition meets innovation for a truly memorable dining adventure. It\'s an ideal choice for those seeking a unique and unforgettable flavor journey. Join us to savor the extraordinary combination of seafood and soybean sauce that transcends the ordinary.'),
(19, 'Iced Tea', 500, 3, 'image/menu/500_Iced_Tea.jpg', 'Quench your thirst and refresh your senses with our Iced Tea, a classic and timeless beverage that\'s the perfect companion for any meal. Our Iced Tea is brewed to perfection, then carefully chilled to create a harmonious blend of pure, clean flavors.\r\n\r\nWith its subtle yet satisfying taste, our Iced Tea is the ideal choice to complement your dining experience. Whether it\'s a hot summer\'s day or a cozy evening indoors, this refreshing beverage is a delightful way to cleanse the palate and enhance your meal.\r\n\r\nSip on the simplicity and purity of our Iced Tea, a beverage that transcends seasons and offers a moment of relaxation in every glass. Join us and enjoy this timeless and cooling classic.'),
(20, 'Orange Juice with Mint', 500, 3, 'image/menu/500_Orange_Juice_Mint.jpg', 'Reinvigorate your taste buds with our Orange Juice with Mint, a delightful and revitalizing beverage that harmoniously blends the zesty brightness of fresh oranges with the invigorating aroma of mint leaves. This vibrant concoction is a true celebration of natural flavors.\r\n\r\nOur freshly squeezed orange juice, combined with the refreshing essence of mint, creates a drink that\'s both vibrant and soothing. The citrusy sweetness of oranges mingles with the cool, herbal notes of mint, offering a symphony of tastes that\'s both uplifting and invigorating.\r\n\r\nOrange Juice with Mint is the perfect choice for those seeking a revitalizing and palate-cleansing experience. Whether it\'s to kickstart your day or to accompany a delightful meal, this beverage is a burst of freshness in every sip. Join us and savor this invigorating fusion of flavors.'),
(21, 'Smoothie Strawberry', 500, 3, 'image/menu/500_Smoothie_Strawberry.jpg', 'Indulge in a burst of natural sweetness with our Strawberry Smoothie, a luscious and refreshing concoction that embodies the essence of summer. Our smoothie is crafted with plump, ripe strawberries blended to perfection, creating a symphony of delightful flavors.\r\n\r\nEvery sip of our Strawberry Smoothie is like a journey through a sun-kissed strawberry field. It\'s a harmonious balance of fruity sweetness and a velvety texture, making it a perfect choice for those who crave a refreshing and wholesome treat.\r\n\r\nWhether you\'re starting your day or looking for a revitalizing pick-me-up, our Strawberry Smoothie is a delightful way to invigorate your senses. Join us to experience the sheer bliss of this fruity sensation.');

-- --------------------------------------------------------

--
-- Table structure for table `tblgallery`
--

CREATE TABLE `tblgallery` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblgallery`
--

INSERT INTO `tblgallery` (`id`, `title`, `file_path`) VALUES
(1, 'Angus Burger', 'image/Angus Burger.png'),
(2, 'Chicken Soup', 'image/ChickenSoup.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` char(2) DEFAULT NULL,
  `zip` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`, `fname`, `lname`, `phone`, `address`, `city`, `province`, `zip`) VALUES
(1, 'admin@admin.com', '$2y$10$oxLOUCIsHacyV/OgBske/.J14c7nnNMj4Ta33uE3OzVWIVl38clZy', 'admin', 'Mark', 'Sumoba', '0000000000', '203 sherbrooke st', 'Montreal', 'QC', 'A2A1H1'),
(28, 'skk@skk.com', '$2y$10$DsXU8t4GWQOj5SAeymRi4e6Z0lnlqCjuyqbxIrLf8Iq0HMdHjtUAi', 'user', 'SangKyu', 'Kim', '0000000000', '54 3e avenue', 'Montreal', 'QC', 'H2H3J3'),
(29, 'mjs@mjs.com', '$2y$10$EUc4/FVARl4n0wFevC1Bs.3LCrr0UeKnU0wx8ujIakwDLx2aDrtiS', 'user', 'Mark', 'Sumoba', '1234567890', '203 sherbrooke st', 'Montreal', 'QC', 'A2A1H1'),
(30, 'nrt@nrt.com', '$2y$10$0pOeQp83Ex6V4GMS7iCgPOXSTicTNwjl/LnP/MJjhBWtGey3lZlmC', 'user', 'Nori', 'Nori', '0000000000', '123 chambly ave.', 'Montreal', 'QC', 'H1H2G2'),
(31, 'cmt@cmt.com', '$2y$10$ZExznmuSAyTpdvXlZwRoTOTwtXObW8ODqemlYuGfwAUyPzP9eJOKm', 'user', 'claudio', 'terrence', '0000000000', '38 verdun st', 'Montreal', 'QC', 'H1H2G2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `food_cat`
--
ALTER TABLE `food_cat`
  ADD PRIMARY KEY (`foodcat_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `menu_foodCat_id_fk` (`foodcat_id`);

--
-- Indexes for table `tblgallery`
--
ALTER TABLE `tblgallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblgallery`
--
ALTER TABLE `tblgallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_foodCat_id_fk` FOREIGN KEY (`foodcat_id`) REFERENCES `food_cat` (`foodcat_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
